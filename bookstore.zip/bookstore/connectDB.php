<?php
$pdo=new PDO('mysql:host=192.168.5.170;port=3306;dbname=bookstore','dbuser', 'myP@ssw0rd');
?>